package com.bpd.bestpricedelivery.inerface;

public interface GlobleInterfce {
    String  Base_URl = "http://bestpricedelivery.com/public/api/v1/customer/";
}
