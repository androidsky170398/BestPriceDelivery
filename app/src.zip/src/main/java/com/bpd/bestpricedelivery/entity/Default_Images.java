package com.bpd.bestpricedelivery.entity;

public class Default_Images {
    String sitelogo, default_site_logo, user_default_image, category_default_image, product_default_image;

    public String getSitelogo() {
        return sitelogo;
    }

    public void setSitelogo(String sitelogo) {
        this.sitelogo = sitelogo;
    }

    public String getDefault_site_logo() {
        return default_site_logo;
    }

    public void setDefault_site_logo(String default_site_logo) {
        this.default_site_logo = default_site_logo;
    }

    public String getUser_default_image() {
        return user_default_image;
    }

    public void setUser_default_image(String user_default_image) {
        this.user_default_image = user_default_image;
    }

    public String getCategory_default_image() {
        return category_default_image;
    }

    public void setCategory_default_image(String category_default_image) {
        this.category_default_image = category_default_image;
    }

    public String getProduct_default_image() {
        return product_default_image;
    }

    public void setProduct_default_image(String product_default_image) {
        this.product_default_image = product_default_image;
    }
}
