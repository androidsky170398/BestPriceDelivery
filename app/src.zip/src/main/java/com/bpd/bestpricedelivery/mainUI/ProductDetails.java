package com.bpd.bestpricedelivery.mainUI;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bpd.bestpricedelivery.R;
import com.bpd.bestpricedelivery.entity.ProductData;
import com.bpd.bestpricedelivery.sqliteDatabase.DataSource;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.Serializable;
import java.util.List;

public class ProductDetails extends AppCompatActivity {
    ImageView img_product, iv_brandImage;
    TextView tv_City, tv_ProductName, tv_ProductDescription, tv_BrandName;
    Button btn_BuyNow, btn_AddtoCart;
    LinearLayout ll_forbtn;
    ProductData productData;
    String fromWhere;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Product Details");
        findViewByIds();

        Intent intent = getIntent();
        productData = (ProductData) intent.getSerializableExtra("ProductDetails");
        fromWhere = intent.getStringExtra("fromWhere");
        if (fromWhere != null && fromWhere.equalsIgnoreCase("Cart")) {
            ll_forbtn.setVisibility(View.GONE);
        } else if (fromWhere != null && fromWhere.equalsIgnoreCase("MyOrder")) {

        } else {
            if (Integer.parseInt(productData.getTotal_availability()) > 0) {
                ll_forbtn.setVisibility(View.VISIBLE);
            } else {
                ll_forbtn.setVisibility(View.GONE);
            }
        }
        if (productData != null) {
            if (productData.getProduct_image() != null && !productData.getProduct_image().equalsIgnoreCase("")) {
                Picasso.with(ProductDetails.this).load(productData.getProduct_image()).placeholder(R.drawable.placeholder).into(new Target() {

                    @Override
                    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {

                        img_product.setImageBitmap(bitmap);
                        //img_product.setScaleType(ImageView.ScaleType.FIT_XY);
                    }

                    @Override
                    public void onPrepareLoad(Drawable placeHolderDrawable) {
                    }

                    @Override
                    public void onBitmapFailed(Drawable errorDrawable) {
                    }
                });
            }

            if (productData.getProductname() != null && !productData.getProductname().equalsIgnoreCase("")) {
                tv_ProductName.setText(productData.getProductname());
            } else {
                tv_ProductName.setText("N/A");
            }

            if (productData.getCity_id() != null && !productData.getCity_id().equalsIgnoreCase("")) {
                tv_City.setText(productData.getCity_name());
            } else {
                tv_City.setText("N/A");
            }
            if (productData.getBrand_image() != null && !productData.getBrand_image().equalsIgnoreCase("")) {

                Picasso.with(ProductDetails.this).load(productData.getBrand_image()).placeholder(R.drawable.placeholder).into(new Target() {

                    @Override
                    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {

                        iv_brandImage.setImageBitmap(bitmap);
                        //iv_brandImage.setScaleType(ImageView.ScaleType.FIT_XY);
                    }

                    @Override
                    public void onPrepareLoad(Drawable placeHolderDrawable) {
                    }

                    @Override
                    public void onBitmapFailed(Drawable errorDrawable) {
                    }
                });
            } else {

            }
            if (productData.getBrandname() != null && !productData.getBrandname().equalsIgnoreCase("")) {
                tv_BrandName.setText(productData.getBrandname());
            } else {
                tv_BrandName.setText("N/A");
            }
            if (productData.getDescription() != null && !productData.getDescription().equalsIgnoreCase("")) {
                tv_ProductDescription.setText(productData.getDescription());
            } else {
                tv_ProductDescription.setText("N/A");
            }
        }

        btn_AddtoCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count = 0;
                DataSource dataSource = new DataSource(ProductDetails.this);
                dataSource.open();
                ProductData productData1;
                try {
                    productData1 = dataSource.selectInto_tbl_Products(productData.getId(), productData.getQuantity_name()).get(0);
                } catch (Exception e) {
                    productData1 = null;
                }
                if (productData1 != null) {
                    productData1.setSelected_quantity((Integer.parseInt(productData1.getSelected_quantity()) + 1) + "");
                    count = dataSource.updateInto_tbl_Products(productData1.getCommon_id(), productData1);
                } else {
                    count = (int) dataSource.insertInto_tbl_Products(productData);
                }
                dataSource.close();
                if (count > 0) {
                    Toast.makeText(ProductDetails.this, "Product added successfully!!!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ProductDetails.this, CartActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
                }
            }
        });
        //Dashboard.checkNetConnection(ProductDetails.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Dashboard.checkNetConnection(ProductDetails.this);
    }

    private void findViewByIds() {
        img_product = findViewById(R.id.img_product);
        iv_brandImage = findViewById(R.id.iv_brandImage);
        tv_City = findViewById(R.id.tv_City);
        tv_ProductName = findViewById(R.id.tv_ProductName);
        tv_ProductDescription = findViewById(R.id.tv_ProductDescription);
        btn_BuyNow = findViewById(R.id.btn_BuyNow);
        btn_AddtoCart = findViewById(R.id.btn_AddtoCart);
        ll_forbtn = findViewById(R.id.ll_forbtn);
        tv_BrandName = findViewById(R.id.tv_BrandName);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}
