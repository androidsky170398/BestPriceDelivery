package com.bpd.bestpricedelivery.mainUI;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bpd.bestpricedelivery.Adapter.AdapterForCart;
import com.bpd.bestpricedelivery.Helper.NetworkConnectionHelper;
import com.bpd.bestpricedelivery.R;
import com.bpd.bestpricedelivery.Util.Constants;
import com.bpd.bestpricedelivery.entity.ProductData;
import com.bpd.bestpricedelivery.sqliteDatabase.DataSource;

import java.util.ArrayList;
import java.util.List;

public class CartActivity extends AppCompatActivity {
    RecyclerView rv_cartList;
    TextView tv_noData;
    GridLayoutManager gridLayoutManager;
    List<ProductData> list_Products = new ArrayList<>();
    TextView tv_totalRs, tv_totalsave;
    Button btn_checkout;
    LinearLayout ll_main;
    int totalPrice = 0, TotalSave = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("My Cart");
        ll_main = findViewById(R.id.ll_main);
        tv_totalRs = findViewById(R.id.tv_totalRs);
        tv_totalsave = findViewById(R.id.tv_totalsave);
        btn_checkout = findViewById(R.id.btn_checkout);
        rv_cartList = (RecyclerView) findViewById(R.id.rv_cartList);
        tv_noData = (TextView) findViewById(R.id.tv_noData);
        gridLayoutManager = new GridLayoutManager(CartActivity.this, 1);
        rv_cartList.setLayoutManager(gridLayoutManager);
        DataSource dataSource = new DataSource(CartActivity.this);
        dataSource.open();
        list_Products = dataSource.selectInto_tbl_Products("", "");
        dataSource.close();
        if (list_Products != null && list_Products.size() > 0) {
            ll_main.setVisibility(View.VISIBLE);
            rv_cartList.setVisibility(View.VISIBLE);
            tv_noData.setVisibility(View.GONE);
            AdapterForCart adapterForCart = new AdapterForCart(CartActivity.this, list_Products, tv_totalRs, tv_totalsave);
            rv_cartList.setAdapter(adapterForCart);
            CartActivity.totalRsforCart(CartActivity.this, tv_totalRs, tv_totalsave);
            /*for (int i = 0; i < list_Products.size(); i++) {
                totalPrice += Integer.parseInt(list_Products.get(i).getSelling_price()) * Integer.parseInt(list_Products.get(i).getSelected_quantity());
                TotalSave += Integer.parseInt(list_Products.get(i).getPrice()) * Integer.parseInt(list_Products.get(i).getSelected_quantity());
            }
            tv_totalRs.setText("Rs " + totalPrice);
            tv_totalsave.setText("You save " + (TotalSave - totalPrice));*/
        } else {
            ll_main.setVisibility(View.GONE);
            rv_cartList.setVisibility(View.GONE);
            tv_noData.setVisibility(View.VISIBLE);
        }
        btn_checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetworkConnectionHelper.isOnline(CartActivity.this)) {
                    if (Constants.getSavedPreferences(CartActivity.this, Constants.ID, null) != null) {
                        startActivity(new Intent(CartActivity.this, AddressList.class).putExtra("totalPrice", ((tv_totalRs.getText().toString().trim()).split(" ")[1])));
                    } else {
                        startActivity(new Intent(CartActivity.this, SendOtpActivity.class));
                    }
                } else {
                    Toast.makeText(CartActivity.this, "Please check your internet connection! try again...", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(CartActivity.this, Dashboard.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    public static void totalRsforCart(Context context, TextView tv_totalRs, TextView tv_totalsave) {
        int totalPrice = 0, TotalSave = 0;
        DataSource dataSource = new DataSource(context);
        dataSource.open();
        List<ProductData> list_Products = dataSource.selectInto_tbl_Products("", "");
        for (int i = 0; i < list_Products.size(); i++) {
            totalPrice += Double.parseDouble(list_Products.get(i).getSelling_price()) * Double.parseDouble(list_Products.get(i).getSelected_quantity());
            TotalSave += Double.parseDouble(list_Products.get(i).getPrice()) * Double.parseDouble(list_Products.get(i).getSelected_quantity());
        }
        tv_totalRs.setText("Rs " + totalPrice);
        tv_totalsave.setText("You save Rs " + (TotalSave - totalPrice));
    }
}
