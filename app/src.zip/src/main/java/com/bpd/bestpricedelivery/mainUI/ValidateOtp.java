package com.bpd.bestpricedelivery.mainUI;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bpd.bestpricedelivery.Helper.NetworkConnectionHelper;
import com.bpd.bestpricedelivery.LocationTrack.GPSTracker;
import com.bpd.bestpricedelivery.MainActivity;
import com.bpd.bestpricedelivery.R;
import com.bpd.bestpricedelivery.Util.Constants;
import com.bpd.bestpricedelivery.inerface.GlobleInterfce;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.bpd.bestpricedelivery.Util.Constants.ID;
import static com.bpd.bestpricedelivery.Util.Constants.User_Email;
import static com.bpd.bestpricedelivery.Util.Constants.User_Mobile;
import static com.bpd.bestpricedelivery.Util.Constants.User_Name;


public class ValidateOtp extends AppCompatActivity implements GlobleInterfce {

    TextInputEditText edt_otp;
    TextView txt_resendotp;
    Button btn_validateOtp;
    String validate_url = "validate-otp";
    String resend_url = "send-otp";
    Double latitude, longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validate_otp);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Validate Otp");
        edt_otp = findViewById(R.id.edt_otp);
        txt_resendotp = findViewById(R.id.txt_resendotp);
        btn_validateOtp = findViewById(R.id.btn_validateOtp);
        GPSTracker gpsTracker = new GPSTracker(ValidateOtp.this);
        if (gpsTracker.canGetLocation()) {
            latitude = gpsTracker.getLatitude();
            longitude = gpsTracker.getLongitude();

        } else {
            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gpsTracker.showSettingsAlert();
        }
        btn_validateOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetworkConnectionHelper.isOnline(ValidateOtp.this))
                    validateOtp();
                else
                    Toast.makeText(ValidateOtp.this, "Please Check InterNet Connection", Toast.LENGTH_SHORT).show();

            }
        });
        txt_resendotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetworkConnectionHelper.isOnline(ValidateOtp.this))
                    resendOtp();
                else
                    Toast.makeText(ValidateOtp.this, "Please Check InterNet Connection", Toast.LENGTH_SHORT).show();

            }
        });
    }

    public void validateOtp() {
        final ProgressDialog progressDialog = new ProgressDialog(ValidateOtp.this);
        progressDialog.setMessage("Loading");
        progressDialog.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_URl + validate_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getBoolean("status")) {
                        JSONObject jsonObject1 = jsonObject.getJSONObject("data");
                        Constants.savePreferences(ValidateOtp.this, ID, jsonObject1.getString("id"));
                        Constants.savePreferences(ValidateOtp.this, User_Name, jsonObject1.getString("name"));
                        Constants.savePreferences(ValidateOtp.this, User_Email, jsonObject1.getString("email"));
                        Constants.savePreferences(ValidateOtp.this, User_Mobile, jsonObject1.getString("mobile"));
                        Toast.makeText(ValidateOtp.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ValidateOtp.this, Dashboard.class));
                        finish();
                    } else {
                        Toast.makeText(ValidateOtp.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //  Toast.makeText(ValidateOtp.this, response, Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(ValidateOtp.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("mobile_no", getIntent().getStringExtra("mobileNo"));
                params.put("otp_text", edt_otp.getText().toString().trim());
                params.put("latitude", latitude + "");
                params.put("longitude", longitude + "");
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ValidateOtp.this);
        requestQueue.add(stringRequest);
        //Dashboard.checkNetConnection(ValidateOtp.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Dashboard.checkNetConnection(ValidateOtp.this);
    }

    public void resendOtp() {
        final ProgressDialog progressDialog = new ProgressDialog(ValidateOtp.this);
        progressDialog.setMessage("Sending Otp");
        progressDialog.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_URl + resend_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getBoolean("status")) {

                        Toast.makeText(ValidateOtp.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(ValidateOtp.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("mobile_no", getIntent().getStringExtra("mobileNo"));
                params.put("latitude", latitude + "");
                params.put("longitude", longitude + "");
                return super.getParams();
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ValidateOtp.this);
        requestQueue.add(stringRequest);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}
