package com.bpd.bestpricedelivery.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.bpd.bestpricedelivery.Helper.NetworkConnectionHelper;
import com.bpd.bestpricedelivery.R;
import com.bpd.bestpricedelivery.entity.ProductData;
import com.bpd.bestpricedelivery.mainUI.ActivityProduct;
import com.bpd.bestpricedelivery.mainUI.MyOrderDetails;

import java.util.ArrayList;
import java.util.List;

public class AdapterForMyOrder extends RecyclerView.Adapter<AdapterForMyOrder.ViewHolder> {
    Context context;
    List<ProductData> productDataList = new ArrayList<>();

    public AdapterForMyOrder(Context context, List<ProductData> productDataList) {
        this.context = context;
        this.productDataList = productDataList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_for_myorder, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {
        viewHolder.tv_inviceId.setText(productDataList.get(i).getInvoice_id());
        viewHolder.tv_orderDate.setText(productDataList.get(i).getOrder_date());
        viewHolder.tv_Status.setText(productDataList.get(i).getStatus());

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetworkConnectionHelper.isOnline(context)) {
                    context.startActivity(new Intent(context, MyOrderDetails.class)
                            .putExtra("order_id", productDataList.get(i)
                                    .getId()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } else {
                    Toast.makeText(context, "Please check your internet connection! try again...", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    @Override
    public int getItemCount() {
        return productDataList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_inviceId, tv_orderDate, tv_Status;

        public ViewHolder(View v) {
            super(v);
            tv_inviceId = v.findViewById(R.id.tv_inviceId);
            tv_orderDate = v.findViewById(R.id.tv_orderDate);
            tv_Status = v.findViewById(R.id.tv_Status);
        }
    }
}
