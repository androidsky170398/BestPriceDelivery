package com.bpd.bestpricedelivery.entity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.List;

public class WalletData implements Serializable {
    String wallet_amount;
    User userdetails = new User();
    Order_Settings order_setting = new Order_Settings();
    Order_Settings is_cashback_applied = new Order_Settings();
    Default_Images default_images = new Default_Images();

    public String getWallet_amount() {
        return wallet_amount;
    }

    public void setWallet_amount(String wallet_amount) {
        this.wallet_amount = wallet_amount;
    }

    public User getUserdetails() {
        return userdetails;
    }

    public void setUserdetails(User userdetails) {
        this.userdetails = userdetails;
    }

    public Order_Settings getOrder_setting() {
        return order_setting;
    }

    public void setOrder_setting(Order_Settings order_setting) {
        this.order_setting = order_setting;
    }

    public Order_Settings getIs_cashback_applied() {
        return is_cashback_applied;
    }

    public void setIs_cashback_applied(Order_Settings is_cashback_applied) {
        this.is_cashback_applied = is_cashback_applied;
    }

    public Default_Images getDefault_images() {
        return default_images;
    }

    public void setDefault_images(Default_Images default_images) {
        this.default_images = default_images;
    }

    public static WalletData createJsonInList(String str) {
        Gson gson = new Gson();
        Type type = new TypeToken<WalletData>() {
        }.getType();
        return gson.fromJson(str, type);
    }
    
}
