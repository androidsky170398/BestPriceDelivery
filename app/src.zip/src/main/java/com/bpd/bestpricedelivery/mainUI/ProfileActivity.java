package com.bpd.bestpricedelivery.mainUI;

import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import com.bpd.bestpricedelivery.R;
import com.bpd.bestpricedelivery.Util.Constants;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {

    TextInputEditText edt_name, edt_email, edt_mobile;
    CircleImageView img_showprofilepic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Profile");
        edt_name = findViewById(R.id.edt_name);
        edt_email = findViewById(R.id.edt_email);
        edt_mobile = findViewById(R.id.edt_mobile);
        img_showprofilepic = findViewById(R.id.img_showprofilepic);
        edt_mobile.setKeyListener(null);
        if (!Constants.getSavedPreferences(ProfileActivity.this, Constants.User_Name, "").equalsIgnoreCase("")) {
            edt_name.setText(Constants.getSavedPreferences(ProfileActivity.this, Constants.User_Name, ""));
        }
        if (!Constants.getSavedPreferences(ProfileActivity.this, Constants.User_Name, "").equalsIgnoreCase("")) {
            edt_email.setText(Constants.getSavedPreferences(ProfileActivity.this, Constants.User_Email, ""));
        }

        if (!Constants.getSavedPreferences(ProfileActivity.this, Constants.User_Name, "").equalsIgnoreCase("")) {
            edt_mobile.setText(Constants.getSavedPreferences(ProfileActivity.this, Constants.User_Mobile, ""));
        }
       // Dashboard.checkNetConnection(ProfileActivity.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
       // Dashboard.checkNetConnection(ProfileActivity.this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}
