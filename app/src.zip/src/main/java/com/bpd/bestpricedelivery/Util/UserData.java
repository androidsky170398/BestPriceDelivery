package com.bpd.bestpricedelivery.Util;

import android.content.Context;
import android.content.SharedPreferences;

public class UserData   {
    Context context;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String Id, Name,Email,Mobile;
}
