package com.bpd.bestpricedelivery.fragment;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bpd.bestpricedelivery.Adapter.AdapterForBanner;
import com.bpd.bestpricedelivery.Adapter.AdapterForCategoryHome;
import com.bpd.bestpricedelivery.Helper.CurrentCityDialog;
import com.bpd.bestpricedelivery.Helper.NetworkConnectionHelper;
import com.bpd.bestpricedelivery.R;
import com.bpd.bestpricedelivery.Util.Constants;
import com.bpd.bestpricedelivery.entity.BannerData;
import com.bpd.bestpricedelivery.entity.CategoryData;
import com.bpd.bestpricedelivery.inerface.GlobleInterfce;
import com.bpd.bestpricedelivery.mainUI.Dashboard;
import com.viewpagerindicator.CirclePageIndicator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static com.bpd.bestpricedelivery.Util.Constants.CITY_NAME;

/**
 * A simple {@link Fragment} subclass.
 */
public class Home_Fragment extends Fragment implements GlobleInterfce {

    RecyclerView rv_Item_category;
    GridLayoutManager gridLayoutManager;
    List<String> list = new ArrayList<>();

    public Home_Fragment() {
        // Required empty public constructor
    }

    String url = "category";
    List<CategoryData> categoryData = new ArrayList<>();
    List<BannerData> bannerData = new ArrayList<>();
    String bannerUrl = "bannerlist";
    ViewPager viewPager_banner;
    private static int currentPage = 0;
    CirclePageIndicator indicator;
    SwipeRefreshLayout srl_Refresh;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home_, container, false);
        rv_Item_category = (RecyclerView) view.findViewById(R.id.rv_Item_category);
        viewPager_banner = (ViewPager) view.findViewById(R.id.viewPager_banner);
        indicator = (CirclePageIndicator) view.findViewById(R.id.indicator);
        srl_Refresh = view.findViewById(R.id.srl_Refresh);
        srl_Refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (NetworkConnectionHelper.isOnline(getActivity())) {
                    getBanner();
                    getData();
                } else {
                    Toast.makeText(getActivity(), "Please check your internet connection! try again...", Toast.LENGTH_SHORT).show();
                }
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        srl_Refresh.setRefreshing(false);
                    }
                }, 2000);
            }
        });

        /*  for (int i = 0; i < 12; i++) {
            list.add("Item " + i);
        }
        gridLayoutManager = new GridLayoutManager(getActivity(), 3);
        rv_Item_category.setHasFixedSize(true);
        rv_Item_category.setLayoutManager(gridLayoutManager);
        AdapterForCategoryHome adapterForCategoryHome = new AdapterForCategoryHome(getActivity(), list);
        rv_Item_category.setAdapter(adapterForCategoryHome);*/

        if (NetworkConnectionHelper.isOnline(getActivity())) {
            getBanner();
            getData();
        } else {
            Toast.makeText(getActivity(), "Please check your internet connection! try again...", Toast.LENGTH_SHORT).show();
        }
        return view;
    }

    public void getData() {
        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.show();
        progressDialog.setMessage("Loading");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_URl + url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                //  Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getBoolean("status")) {
                        String jsonInString = jsonObject.getString("data");
                        categoryData = CategoryData.createJsonInList(jsonInString);
                        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 3);
                        AdapterForCategoryHome myAdapter = new AdapterForCategoryHome(getActivity(), categoryData);
                        rv_Item_category.setLayoutManager(gridLayoutManager);
                        rv_Item_category.setAdapter(myAdapter);
                        rv_Item_category.setHasFixedSize(true);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);

    }

    public void getBanner() {
        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.show();
        progressDialog.setMessage("Loading");
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Base_URl + bannerUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString("status").equalsIgnoreCase("True")) {
                        JSONObject jsonObject1 = jsonObject.getJSONObject("data");
                        String JsonInString = jsonObject1.getString("banner");
                        bannerData = BannerData.createJsonInList(JsonInString);
                    }

                    viewPager_banner.setAdapter(new AdapterForBanner(getActivity(), bannerData));
                    indicator.setViewPager(viewPager_banner);
                    final float density = getResources().getDisplayMetrics().density;

//Set circle indicator radius
                    indicator.setRadius(2 * density);

                    // Auto start of viewpager
                    final Handler handler = new Handler();
                    final Runnable Update = new Runnable() {
                        public void run() {
                            if (currentPage == bannerData.size()) {
                                currentPage = 0;
                            }
                            viewPager_banner.setCurrentItem(currentPage++, true);
                        }
                    };
                    Timer swipeTimer = new Timer();
                    swipeTimer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            handler.post(Update);
                        }
                    }, 5000, 3000);
// Pager listener over indicator
                    indicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

                        @Override
                        public void onPageSelected(int position) {
                            currentPage = position;
                        }

                        @Override
                        public void onPageScrolled(int pos, float arg1, int arg2) {

                        }

                        @Override
                        public void onPageScrollStateChanged(int pos) {

                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                //  Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
    }

}
