package com.bpd.bestpricedelivery.mainUI;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bpd.bestpricedelivery.Helper.NetworkConnectionHelper;
import com.bpd.bestpricedelivery.LocationTrack.GPSTracker;
import com.bpd.bestpricedelivery.R;
import com.bpd.bestpricedelivery.inerface.GlobleInterfce;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SendOtpActivity extends AppCompatActivity implements GlobleInterfce {

    String url = "send-otp";
    TextInputEditText edt_mobileNo;
    Button btn_sendOtp;

    double latitude, longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_otp);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Login");
        edt_mobileNo = findViewById(R.id.edt_mobileNo);
        btn_sendOtp = findViewById(R.id.btn_sendOtp);
        GPSTracker gpsTracker = new GPSTracker(SendOtpActivity.this);
        if (gpsTracker.canGetLocation()) {
            latitude = gpsTracker.getLatitude();
            longitude = gpsTracker.getLongitude();

        } else {
            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gpsTracker.showSettingsAlert();
        }
        btn_sendOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetworkConnectionHelper.isOnline(SendOtpActivity.this))
                    sendOtp();
                else
                    Toast.makeText(SendOtpActivity.this, "Please Check InterNet Connection", Toast.LENGTH_SHORT).show();
            }
        });
        //Dashboard.checkNetConnection(SendOtpActivity.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Dashboard.checkNetConnection(SendOtpActivity.this);
    }

    public void sendOtp() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading");
        progressDialog.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Base_URl + url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                //    Toast.makeText(SendOtpActivity.this, response, Toast.LENGTH_SHORT).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getBoolean("status")) {
                        Toast.makeText(SendOtpActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                        JSONObject jsonObject1 = jsonObject.getJSONObject("data");
                        if (jsonObject1.has("mobile")) {
                            //  JSONObject jsonObject1=jsonObject.getJSONObject("data");
                            startActivity(new Intent(SendOtpActivity.this, ValidateOtp.class).putExtra("mobileNo", jsonObject1.getString("mobile")));
                            finish();
                        }
                    } else {
                        JSONObject jsonObject1 = jsonObject.getJSONObject("data");
                        if (jsonObject1.has("mobile")) {
                            Toast.makeText(SendOtpActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(SendOtpActivity.this, SignupActivity.class).putExtra("mobileNo", jsonObject1.getString("mobile")));
                        } else {
                            JSONObject jsonObject2 = jsonObject.getJSONObject("error_code");
                            if (jsonObject2.has("mobile_no"))
                                Toast.makeText(SendOtpActivity.this, jsonObject2.getString("mobile_no"), Toast.LENGTH_LONG).show();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(SendOtpActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("mobile_no", edt_mobileNo.getText().toString().trim());
                params.put("latitude", latitude + "");
                params.put("longitude", longitude + "");
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(SendOtpActivity.this);
        requestQueue.add(stringRequest);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}
